package contactapp;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class ContactServiceTest {

    private ContactService contactService;
    private Contact contact;

    @BeforeEach
    public void setUp() {
        contactService = new ContactService();
        contact = new Contact("123", "John", "Doe", "1234567890", "123 Main St");
        contactService.addContact(contact);
    }

    @Test
    public void testAddContact() {
        Contact newContact = new Contact("124", "Jane", "Smith", "0987654321", "456 Oak St");
        contactService.addContact(newContact);
        assertEquals(newContact, contactService.getContact("124"));
    }

    @Test
    public void testAddDuplicateContactThrowsException() {
        Contact duplicateContact = new Contact("123", "Jon", "Doe", "1112223333", "789 Pine St");
        assertThrows(IllegalArgumentException.class, () -> contactService.addContact(duplicateContact));
    }

    @Test
    public void testDeleteContact() {
        contactService.deleteContact("123");
        assertNull(contactService.getContact("123"));
    }

    @Test
    public void testDeleteNonExistentContactThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> contactService.deleteContact("999"));
    }

    @Test
    public void testUpdateFirstName() {
        contactService.updateFirstName("123", "Mike");
        assertEquals("Mike", contactService.getContact("123").getFirstName());
    }

    @Test
    public void testUpdateLastName() {
        contactService.updateLastName("123", "Smith");
        assertEquals("Smith", contactService.getContact("123").getLastName());
    }

    @Test
    public void testUpdatePhone() {
        contactService.updatePhone("123", "9876543210");
        assertEquals("9876543210", contactService.getContact("123").getPhone());
    }

    @Test
    public void testUpdateAddress() {
        contactService.updateAddress("123", "789 Maple St");
        assertEquals("789 Maple St", contactService.getContact("123").getAddress());
    }

    @Test
    public void testUpdateNonExistentContactThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> contactService.updateFirstName("999", "Test"));
        assertThrows(IllegalArgumentException.class, () -> contactService.updateLastName("999", "Test"));
        assertThrows(IllegalArgumentException.class, () -> contactService.updatePhone("999", "9876543210"));
        assertThrows(IllegalArgumentException.class, () -> contactService.updateAddress("999", "123 Test St"));
    }

    @Test
    public void testGetContact() {
        Contact retrievedContact = contactService.getContact("123");
        assertNotNull(retrievedContact);
        assertEquals("John", retrievedContact.getFirstName());
        assertEquals("Doe", retrievedContact.getLastName());
    }

    @Test
    public void testAddNullContactThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> contactService.addContact(null));
    }

    @Test
    public void testGetNonExistentContactReturnsNull() {
        assertNull(contactService.getContact("999"));
    }

    @Test
    public void testDeleteContactWithInvalidIDThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> contactService.deleteContact("999"));
    }

    @Test
    public void testUpdateFirstNameWithInvalidIDThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> contactService.updateFirstName("999", "Invalid"));
    }
}
