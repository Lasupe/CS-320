package contactapp;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class ContactTest {
    private Contact contact;

    @BeforeEach
    public void setUp() {
        contact = new Contact("123", "John", "Doe", "1234567890", "123 Main St");
    }

    @Test
    public void testConstructorAndGetters() {
        assertEquals("123", contact.getContactID());
        assertEquals("John", contact.getFirstName());
        assertEquals("Doe", contact.getLastName());
        assertEquals("1234567890", contact.getPhone());
        assertEquals("123 Main St", contact.getAddress());
    }

    @Test
    public void testSetFirstName() {
        contact.setFirstName("Jane");
        assertEquals("Jane", contact.getFirstName());
    }

    @Test
    public void testSetLastName() {
        contact.setLastName("Smith");
        assertEquals("Smith", contact.getLastName());
    }

    @Test
    public void testSetPhone() {
        contact.setPhone("0987654321");
        assertEquals("0987654321", contact.getPhone());
    }

    @Test
    public void testSetAddress() {
        contact.setAddress("456 Oak St");
        assertEquals("456 Oak St", contact.getAddress());
    }

    @Test
    public void testToString() {
        String expected = "Contact ID: 123, First Name: John, Last Name: Doe, Phone: 1234567890, Address: 123 Main St";
        assertEquals(expected, contact.toString());
    }

    // Negative Tests
    @Test
    public void testNullFirstNameAllowed() {
        assertThrows(IllegalArgumentException.class, () -> contact.setFirstName(null));
    }

    @Test
    public void testNullLastNameAllowed() {
        assertThrows(IllegalArgumentException.class, () -> contact.setLastName(null));
    }

    @Test
    public void testNullPhoneAllowed() {
        assertThrows(IllegalArgumentException.class, () -> contact.setPhone(null));
    }

    @Test
    public void testNullAddressAllowed() {
        assertThrows(IllegalArgumentException.class, () -> contact.setAddress(null));
    }

    @Test
    public void testEmptyValuesAllowed() {
        assertThrows(IllegalArgumentException.class, () -> new Contact("", "", "", "", ""));
    }

    @Test
    public void testGetContactWithNullIDThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> new Contact(null, "John", "Doe", "1234567890", "123 Main St"));
    }
}
