package contactapp;

import java.util.HashMap;
import java.util.Map;

/**
 * Service class for managing contacts.
 */
public class ContactService {
    private Map<String, Contact> contacts;

    public ContactService() {
        contacts = new HashMap<>();
    }

    /**
     * Adds a new contact.
     * @param contact the contact to add
     * @throws IllegalArgumentException if contact is null or ID already exists
     */
    public void addContact(Contact contact) {
        if (contact == null) {
            throw new IllegalArgumentException("Contact cannot be null.");
        }
        if (contacts.containsKey(contact.getContactID())) {
            throw new IllegalArgumentException("Contact ID already exists.");
        }
        contacts.put(contact.getContactID(), contact);
    }

    /**
     * Deletes a contact by ID.
     * @param contactID the ID of the contact to delete
     * @throws IllegalArgumentException if contact ID does not exist
     */
    public void deleteContact(String contactID) {
        if (!contacts.containsKey(contactID)) {
            throw new IllegalArgumentException("Contact not found.");
        }
        contacts.remove(contactID);
    }

    /**
     * Updates the first name of a contact.
     */
    public void updateFirstName(String contactID, String newFirstName) {
        Contact contact = contacts.get(contactID);
        if (contact == null) {
            throw new IllegalArgumentException("Contact not found.");
        }
        contact.setFirstName(newFirstName);
    }

    /**
     * Updates the last name of a contact.
     */
    public void updateLastName(String contactID, String newLastName) {
        Contact contact = contacts.get(contactID);
        if (contact == null) {
            throw new IllegalArgumentException("Contact not found.");
        }
        contact.setLastName(newLastName);
    }

    /**
     * Updates the phone number of a contact.
     */
    public void updatePhone(String contactID, String newPhone) {
        Contact contact = contacts.get(contactID);
        if (contact == null) {
            throw new IllegalArgumentException("Contact not found.");
        }
        contact.setPhone(newPhone);
    }

    /**
     * Updates the address of a contact.
     */
    public void updateAddress(String contactID, String newAddress) {
        Contact contact = contacts.get(contactID);
        if (contact == null) {
            throw new IllegalArgumentException("Contact not found.");
        }
        contact.setAddress(newAddress);
    }

    /**
     * Retrieves a contact by ID.
     */
    public Contact getContact(String contactID) {
        if (!contacts.containsKey(contactID)) {
            throw new IllegalArgumentException("Contact not found.");
        }
        return contacts.get(contactID);
    }

    /**
     * Retrieves all contacts.
     */
    public Map<String, Contact> getAllContacts() {
        return contacts;
    }
}
